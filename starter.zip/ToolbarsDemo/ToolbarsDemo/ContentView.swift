//
//  ContentView.swift
//  ToolbarsDemo
//
//  Created by Gabriel Theodoropoulos.
//

import SwiftUI

struct ContentView: View {
    @State private var imageData: [ImageModel] = [ImageModel(with: "image1"),
                                                  ImageModel(with: "image2"),
                                                  ImageModel(with: "image3")]
    
    @State private var current: Int = 0
    @State private var showSheet = false
    @State private var description = ""
    @State private var showActionSheet = false
    @State private var showDescription = false
    
    var body: some View {
        EmptyView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
