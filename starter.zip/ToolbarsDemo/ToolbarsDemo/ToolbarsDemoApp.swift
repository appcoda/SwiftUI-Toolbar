//
//  ToolbarsDemoApp.swift
//  ToolbarsDemo
//
//  Created by Gabriel Theodoropoulos.
//

import SwiftUI

@main
struct ToolbarsDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
